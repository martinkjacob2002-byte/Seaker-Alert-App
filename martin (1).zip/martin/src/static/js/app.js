// Seaker Dashboard App
document.addEventListener('DOMContentLoaded', () => {
    let charts = {};
    let historicalData = {
        cpu: Array(30).fill(0),
        mem: Array(30).fill(0),
        disk: Array(30).fill(0),
        labels: Array(30).fill('')
    };

    // Initialize UI
    initCharts();
    startDataRefreshing();

    // Event Listeners
    document.getElementById('refreshBtn').addEventListener('click', refreshData);
    document.getElementById('testAlertBtn').addEventListener('click', testAlert);
    document.getElementById('exportBtn').addEventListener('click', exportData);

    function initCharts() {
        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: { enabled: false } },
            scales: { x: { display: false }, y: { display: false } },
            elements: {
                line: { tension: 0.4, borderWidth: 2, fill: true },
                point: { radius: 0 }
            }
        };

        // Sparklines
        charts.cpuSpark = new Chart(document.getElementById('cpuSpark'), {
            type: 'line',
            data: {
                labels: Array(20).fill(''),
                datasets: [{
                    data: Array(20).fill(0),
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)'
                }]
            },
            options: commonOptions
        });

        charts.memSpark = new Chart(document.getElementById('memSpark'), {
            type: 'line',
            data: {
                labels: Array(20).fill(''),
                datasets: [{
                    data: Array(20).fill(0),
                    borderColor: '#14b8a6',
                    backgroundColor: 'rgba(20, 184, 166, 0.1)'
                }]
            },
            options: commonOptions
        });

        charts.diskSpark = new Chart(document.getElementById('diskSpark'), {
            type: 'line',
            data: {
                labels: Array(20).fill(''),
                datasets: [{
                    data: Array(20).fill(0),
                    borderColor: '#f43f5e',
                    backgroundColor: 'rgba(244, 63, 94, 0.1)'
                }]
            },
            options: commonOptions
        });

        // Main Performance Chart
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const cpuGradient = ctx.createLinearGradient(0, 0, 0, 400);
        cpuGradient.addColorStop(0, 'rgba(99, 102, 241, 0.4)');
        cpuGradient.addColorStop(1, 'rgba(99, 102, 241, 0)');

        const memGradient = ctx.createLinearGradient(0, 0, 0, 400);
        memGradient.addColorStop(0, 'rgba(20, 184, 166, 0.4)');
        memGradient.addColorStop(1, 'rgba(20, 184, 166, 0)');

        charts.performanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: historicalData.labels,
                datasets: [
                    {
                        label: 'CPU',
                        data: historicalData.cpu,
                        borderColor: '#6366f1',
                        backgroundColor: cpuGradient,
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Memory',
                        data: historicalData.mem,
                        borderColor: '#14b8a6',
                        backgroundColor: memGradient,
                        fill: true,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: { color: '#94a3b8', boxWidth: 10, usePointStyle: true, font: { family: 'Outfit' } }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748b', font: { size: 10 } }
                    },
                    y: {
                        min: 0,
                        max: 100,
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#64748b', font: { size: 10 } }
                    }
                }
            }
        });
    }

    function refreshData() {
        const icon = document.querySelector('#refreshBtn i');
        icon.classList.add('fa-spin');
        
        fetch('/metrics')
            .then(res => res.json())
            .then(data => {
                updateUI(data);
                setTimeout(() => icon.classList.remove('fa-spin'), 500);
            })
            .catch(err => {
                console.error('Error fetching metrics:', err);
                showToast('Connection error. Retrying...', 'error');
                icon.classList.remove('fa-spin');
            });
            
        fetch('/alerts')
            .then(res => res.json())
            .then(data => updateAlerts(data));
    }

    function updateUI(data) {
        // Update main values
        document.getElementById('cpuValue').textContent = data.cpu_usage_percent.toFixed(1);
        document.getElementById('memValue').textContent = data.memory_used_gb.toFixed(2);
        document.getElementById('diskValue').textContent = data.disk_usage_percent.toFixed(1);
        document.getElementById('uptimeValue').textContent = (data.uptime_hours / 24).toFixed(1);
        
        // Stats
        document.getElementById('cpuCores').textContent = data.cpu_count;
        document.getElementById('procCount').textContent = data.process_count;
        document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString();

        // Update Sparklines
        updateSparkline(charts.cpuSpark, data.cpu_usage_percent);
        updateSparkline(charts.memSpark, data.memory_usage_percent);
        updateSparkline(charts.diskSpark, data.disk_usage_percent);

        // Update main chart
        const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        historicalData.labels.shift();
        historicalData.labels.push(now);
        
        historicalData.cpu.shift();
        historicalData.cpu.push(data.cpu_usage_percent);
        
        historicalData.mem.shift();
        historicalData.mem.push(data.memory_usage_percent);
        
        charts.performanceChart.update('none');
    }

    function updateSparkline(chart, value) {
        const data = chart.data.datasets[0].data;
        data.shift();
        data.push(value);
        chart.update('none');
    }

    function updateAlerts(data) {
        const list = document.getElementById('alertsList');
        const count = document.getElementById('alertCount');
        
        if (!data.alerts || data.alerts.length === 0) {
            list.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>All systems normal</p>
                </div>`;
            count.textContent = '0';
            return;
        }

        count.textContent = data.alerts.length;
        list.innerHTML = data.alerts.map(alert => `
            <div class="alert-item ${alert.level}">
                <div class="alert-icon"><i class="fas fa-exclamation-circle"></i></div>
                <div class="alert-info">
                    <div class="alert-title">${alert.metric.replace('_', ' ').toUpperCase()}</div>
                    <div class="alert-desc">${alert.value.toFixed(1)}% exceeded ${alert.threshold}%</div>
                </div>
            </div>
        `).join('');
    }

    function testAlert() {
        fetch('/alerts/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                title: 'Manual Test Alert',
                message: 'Testing notification system connectivity',
                level: 'warning'
            })
        })
        .then(() => showToast('Test alert triggered successfully!'))
        .catch(() => showToast('Failed to trigger alert', 'error'));
    }

    function exportData() {
        window.location.href = '/export/json?time_range=1h';
        showToast('Exporting metrics history...');
    }

    function showToast(msg, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check' : 'fa-times'}"></i>
            <span>${msg}</span>
        `;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 4000);
    }

    function startDataRefreshing() {
        refreshData();
        setInterval(refreshData, 3000);
    }
});
