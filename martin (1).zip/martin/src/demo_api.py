#!/usr/bin/env python3
"""
Demo API for Seaker-Alert-App
Demonstrates functionality without requiring InfluxDB
"""

from flask import Flask, jsonify, request, render_template, send_from_directory
import psutil
import time
import logging
import os
from datetime import datetime
from config_manager import ConfigManager
from notification_service import NotificationService

app = Flask(__name__, 
           template_folder='../templates', 
           static_folder='../static')

# Global instances
config_manager = ConfigManager()
notification_service = NotificationService()

def setup_logging():
    """Setup logging configuration"""
    log_dir = 'logs'
    os.makedirs(log_dir, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'{log_dir}/demo_api.log'),
            logging.StreamHandler()
        ]
    )

def get_system_metrics():
    """Get current system metrics"""
    try:
        # CPU metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        # Memory metrics
        memory = psutil.virtual_memory()
        memory_used_gb = memory.used / (1024**3)
        memory_total_gb = memory.total / (1024**3)
        memory_percent = memory.percent
        
        # Disk metrics
        disk = psutil.disk_usage('/')
        disk_used_gb = disk.used / (1024**3)
        disk_total_gb = disk.total / (1024**3)
        disk_percent = (disk.used / disk.total) * 100
        
        # System metrics
        boot_time = psutil.boot_time()
        uptime_hours = (time.time() - boot_time) / 3600
        process_count = len(psutil.pids())
        
        # Temperature (if available)
        temperature = {}
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                for name, entries in temps.items():
                    for entry in entries:
                        temperature[f"{name}_{entry.label or 'temp'}"] = entry.current
        except (AttributeError, NotImplementedError):
            pass
        
        return {
            'timestamp': datetime.now().isoformat(),
            'cpu_usage_percent': cpu_percent,
            'cpu_count': cpu_count,
            'memory_used_gb': memory_used_gb,
            'memory_total_gb': memory_total_gb,
            'memory_usage_percent': memory_percent,
            'disk_used_gb': disk_used_gb,
            'disk_total_gb': disk_total_gb,
            'disk_usage_percent': disk_percent,
            'uptime_hours': uptime_hours,
            'process_count': process_count,
            'temperature': temperature
        }
    except Exception as e:
        logging.error(f"Error getting system metrics: {e}")
        return {}

def check_alerts(metrics):
    """Check metrics against thresholds and return alerts"""
    alerts = []
    thresholds = config_manager.get_thresholds()
    
    # Check CPU usage
    cpu_thresholds = thresholds.get('cpu_usage', {})
    cpu_value = metrics.get('cpu_usage_percent')
    if cpu_value:
        if cpu_thresholds.get('critical') and cpu_value >= cpu_thresholds['critical']:
            alerts.append({
                'metric': 'cpu_usage',
                'value': cpu_value,
                'threshold': cpu_thresholds['critical'],
                'level': 'critical'
            })
        elif cpu_thresholds.get('warning') and cpu_value >= cpu_thresholds['warning']:
            alerts.append({
                'metric': 'cpu_usage',
                'value': cpu_value,
                'threshold': cpu_thresholds['warning'],
                'level': 'warning'
            })
    
    # Check memory usage
    mem_thresholds = thresholds.get('memory_usage', {})
    mem_value = metrics.get('memory_usage_percent')
    if mem_value:
        if mem_thresholds.get('critical') and mem_value >= mem_thresholds['critical']:
            alerts.append({
                'metric': 'memory_usage',
                'value': mem_value,
                'threshold': mem_thresholds['critical'],
                'level': 'critical'
            })
        elif mem_thresholds.get('warning') and mem_value >= mem_thresholds['warning']:
            alerts.append({
                'metric': 'memory_usage',
                'value': mem_value,
                'threshold': mem_thresholds['warning'],
                'level': 'warning'
            })
    
    # Check disk usage
    disk_thresholds = thresholds.get('disk_usage', {})
    disk_value = metrics.get('disk_usage_percent')
    if disk_value:
        if disk_thresholds.get('critical') and disk_value >= disk_thresholds['critical']:
            alerts.append({
                'metric': 'disk_usage',
                'value': disk_value,
                'threshold': disk_thresholds['critical'],
                'level': 'critical'
            })
        elif disk_thresholds.get('warning') and disk_value >= disk_thresholds['warning']:
            alerts.append({
                'metric': 'disk_usage',
                'value': disk_value,
                'threshold': disk_thresholds['warning'],
                'level': 'warning'
            })
    
    return alerts

@app.route('/')
def index():
    """Root endpoint with project information"""
    return jsonify({
        'name': 'Seaker-Alert-App',
        'version': '1.0.0',
        'description': 'System monitoring and alerting application',
        'status': 'running',
        'endpoints': {
            'health': '/health',
            'metrics': '/metrics',
            'thresholds': '/thresholds',
            'alerts': '/alerts',
            'test_alert': '/alerts/test',
            'dashboard': '/dashboard'
        }
    })

@app.route('/dashboard')
def dashboard():
    """Web UI dashboard"""
    return render_template('dashboard_simple.html')

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'services': {
            'demo_api': 'running',
            'config': 'loaded',
            'metrics': 'available'
        }
    })

@app.route('/metrics', methods=['GET'])
def get_metrics():
    """Get current system metrics"""
    metrics = get_system_metrics()
    return jsonify(metrics)

@app.route('/metrics/history', methods=['GET'])
def get_metrics_history():
    """Get simulated historical metrics"""
    # Simulate some historical data points
    history = []
    current_time = datetime.now()
    
    for i in range(10):
        timestamp = current_time.timestamp() - (i * 300)  # 5 minute intervals
        metrics = get_system_metrics()
        metrics['time'] = datetime.fromtimestamp(timestamp).isoformat()
        history.append(metrics)
    
    return jsonify({
        'metric': 'system_metrics',
        'time_range': '50 minutes',
        'interval': '5 minutes',
        'data': history
    })

@app.route('/thresholds', methods=['GET'])
def get_thresholds():
    """Get alert thresholds"""
    thresholds = config_manager.get_thresholds()
    return jsonify(thresholds)

@app.route('/thresholds', methods=['POST'])
def update_thresholds():
    """Update alert thresholds"""
    try:
        new_thresholds = request.json
        config_manager.update_thresholds(new_thresholds)
        return jsonify({
            'status': 'success',
            'message': 'Thresholds updated successfully',
            'thresholds': new_thresholds
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/alerts', methods=['GET'])
def get_alerts():
    """Get current alert status"""
    metrics = get_system_metrics()
    alerts = check_alerts(metrics)
    
    return jsonify({
        'timestamp': datetime.now().isoformat(),
        'metrics': metrics,
        'alerts': alerts,
        'alert_count': len(alerts)
    })

@app.route('/alerts/test', methods=['POST'])
def test_alert():
    """Send a test alert"""
    try:
        title = request.json.get('title', 'Test Alert')
        message = request.json.get('message', 'This is a test alert from Seaker-Alert-App')
        level = request.json.get('level', 'warning')
        
        notification_service.send_alert(title, message, level)
        
        return jsonify({
            'status': 'success',
            'message': 'Test alert sent successfully',
            'title': title,
            'level': level
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/csv', methods=['GET'])
def export_csv():
    """Export metrics data as CSV"""
    try:
        import csv
        from io import StringIO
        
        # Get current metrics
        metrics = get_system_metrics()
        
        # Create CSV
        output = StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow(['Metric', 'Value', 'Unit'])
        
        # Write metrics
        writer.writerow(['CPU Usage', metrics.get('cpu_usage_percent', 'N/A'), '%'])
        writer.writerow(['Memory Usage', metrics.get('memory_usage_percent', 'N/A'), '%'])
        writer.writerow(['Memory Used', metrics.get('memory_used_gb', 'N/A'), 'GB'])
        writer.writerow(['Memory Total', metrics.get('memory_total_gb', 'N/A'), 'GB'])
        writer.writerow(['Disk Usage', metrics.get('disk_usage_percent', 'N/A'), '%'])
        writer.writerow(['Disk Used', metrics.get('disk_used_gb', 'N/A'), 'GB'])
        writer.writerow(['Disk Total', metrics.get('disk_total_gb', 'N/A'), 'GB'])
        writer.writerow(['Uptime', metrics.get('uptime_hours', 'N/A'), 'Hours'])
        writer.writerow(['Process Count', metrics.get('process_count', 'N/A'), 'Count'])
        
        csv_data = output.getvalue()
        
        return csv_data, 200, {
            'Content-Type': 'text/csv',
            'Content-Disposition': f'attachment; filename=metrics_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        }
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/json', methods=['GET'])
def export_json():
    """Export metrics data as JSON"""
    metrics = get_system_metrics()
    
    return jsonify({
        'export_time': datetime.now().isoformat(),
        'data': metrics
    })

if __name__ == '__main__':
    setup_logging()
    print("Starting Seaker-Alert-App Demo API...")
    print("Access the application at: http://localhost:5000")
    print("Available endpoints:")
    print("  GET  / - Project information")
    print("  GET  /health - Health check")
    print("  GET  /metrics - Current system metrics")
    print("  GET  /alerts - Current alert status")
    print("  POST /alerts/test - Send test alert")
    print("  GET  /thresholds - Get alert thresholds")
    print("  GET  /export/csv - Export as CSV")
    print("  GET  /export/json - Export as JSON")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
