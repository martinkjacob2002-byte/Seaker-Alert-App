#!/usr/bin/env python3
"""
Notification Service for Seaker-Alert-App
Handles sending alerts via various channels (email, Slack, console)
"""

import smtplib
import requests
import logging
import json
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from config_manager import ConfigManager

class NotificationService:
    def __init__(self):
        self.config = ConfigManager()
        self.logger = logging.getLogger(__name__)
        
    def send_console_alert(self, title, message, level):
        """Send alert to console"""
        if not self.config.get_notifications().get('console', {}).get('enabled', True):
            return
            
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        level_symbol = "WARNING" if level == 'warning' else "CRITICAL"
        
        print(f"\n{'='*60}")
        print(f"{level_symbol} ALERT - {timestamp}")
        print(f"Title: {title}")
        print(f"{'='*60}")
        print(message)
        print(f"{'='*60}\n")
        
    def send_email_alert(self, title, message, level):
        """Send alert via email"""
        email_config = self.config.get_notifications().get('email', {})
        
        if not email_config.get('enabled', False):
            return
            
        try:
            # Create message
            msg = MIMEMultipart()
            msg['From'] = email_config['username']
            msg['To'] = ', '.join(email_config['recipients'])
            msg['Subject'] = f"[{level.upper()}] {title}"
            
            # Add body
            body = f"""
{message}

---
Sent by Seaker-Alert-App at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            """.strip()
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Send email
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            
            text = msg.as_string()
            server.sendmail(email_config['username'], email_config['recipients'], text)
            server.quit()
            
            self.logger.info(f"Email alert sent: {title}")
            
        except Exception as e:
            self.logger.error(f"Failed to send email alert: {e}")
            
    def send_slack_alert(self, title, message, level):
        """Send alert via Slack webhook"""
        slack_config = self.config.get_notifications().get('slack', {})
        
        if not slack_config.get('enabled', False):
            return
            
        try:
            webhook_url = slack_config['webhook_url']
            
            # Determine color based on level
            color = 'warning' if level == 'warning' else 'danger'
            
            # Create Slack payload
            payload = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"{level.upper()} Alert: {title}",
                        "text": message,
                        "footer": "Seaker-Alert-App",
                        "ts": datetime.now().timestamp()
                    }
                ]
            }
            
            # Send to Slack
            response = requests.post(webhook_url, json=payload, timeout=10)
            response.raise_for_status()
            
            self.logger.info(f"Slack alert sent: {title}")
            
        except Exception as e:
            self.logger.error(f"Failed to send Slack alert: {e}")
            
    def send_alert(self, title, message, level='warning'):
        """Send alert through all configured channels"""
        self.logger.info(f"Sending alert: {title} ({level})")
        
        # Send to console (always enabled by default)
        self.send_console_alert(title, message, level)
        
        # Send email if configured
        self.send_email_alert(title, message, level)
        
        # Send Slack if configured
        self.send_slack_alert(title, message, level)
        
    def test_notifications(self):
        """Test all notification channels"""
        test_message = "This is a test notification from Seaker-Alert-App"
        
        self.logger.info("Testing notification channels...")
        
        # Test console
        self.send_console_alert("Test Alert", test_message, "warning")
        
        # Test email
        email_config = self.config.get_notifications().get('email', {})
        if email_config.get('enabled', False):
            self.send_email_alert("Test Alert", test_message, "warning")
        else:
            self.logger.info("Email notifications disabled - skipping test")
            
        # Test Slack
        slack_config = self.config.get_notifications().get('slack', {})
        if slack_config.get('enabled', False):
            self.send_slack_alert("Test Alert", test_message, "warning")
        else:
            self.logger.info("Slack notifications disabled - skipping test")
            
        self.logger.info("Notification tests completed")

if __name__ == "__main__":
    # Test notification service
    service = NotificationService()
    service.test_notifications()
