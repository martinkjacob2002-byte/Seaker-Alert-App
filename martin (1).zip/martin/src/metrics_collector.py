#!/usr/bin/env python3
"""
System Metrics Collector for Seaker-Alert-App
Collects system metrics and stores them in InfluxDB
"""

import psutil
import time
import logging
import os
from datetime import datetime
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
from config_manager import ConfigManager

class MetricsCollector:
    def __init__(self):
        self.config = ConfigManager()
        self.influx_client = None
        self.setup_logging()
        self.setup_influxdb()
        
    def setup_logging(self):
        """Setup logging configuration"""
        log_dir = '/app/logs'
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(f'{log_dir}/metrics_collector.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def setup_influxdb(self):
        """Setup InfluxDB connection"""
        try:
            url = f"http://{os.getenv('INFLUXDB_HOST', 'localhost')}:{os.getenv('INFLUXDB_PORT', 8086')}"
            token = f"{os.getenv('INFLUXDB_USER', 'seaker')}:{os.getenv('INFLUXDB_PASSWORD', 'seaker123')}"
            org = "seaker"
            
            self.influx_client = InfluxDBClient(url=url, token=token, org=org)
            self.write_api = self.influx_client.write_api(write_options=SYNCHRONOUS)
            self.logger.info("Connected to InfluxDB successfully")
        except Exception as e:
            self.logger.error(f"Failed to connect to InfluxDB: {e}")
            raise
            
    def get_cpu_metrics(self):
        """Get CPU usage metrics"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            cpu_freq = psutil.cpu_freq()
            
            metrics = {
                'cpu_usage_percent': cpu_percent,
                'cpu_count': cpu_count,
                'cpu_freq_current': cpu_freq.current if cpu_freq else None,
                'cpu_freq_min': cpu_freq.min if cpu_freq else None,
                'cpu_freq_max': cpu_freq.max if cpu_freq else None
            }
            
            return metrics
        except Exception as e:
            self.logger.error(f"Error getting CPU metrics: {e}")
            return {}
            
    def get_memory_metrics(self):
        """Get memory usage metrics"""
        try:
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            metrics = {
                'memory_used_gb': memory.used / (1024**3),
                'memory_available_gb': memory.available / (1024**3),
                'memory_total_gb': memory.total / (1024**3),
                'memory_usage_percent': memory.percent,
                'swap_used_gb': swap.used / (1024**3),
                'swap_total_gb': swap.total / (1024**3),
                'swap_usage_percent': swap.percent
            }
            
            return metrics
        except Exception as e:
            self.logger.error(f"Error getting memory metrics: {e}")
            return {}
            
    def get_disk_metrics(self):
        """Get disk usage metrics"""
        try:
            disk_usage = psutil.disk_usage('/')
            disk_io = psutil.disk_io_counters()
            
            metrics = {
                'disk_used_gb': disk_usage.used / (1024**3),
                'disk_free_gb': disk_usage.free / (1024**3),
                'disk_total_gb': disk_usage.total / (1024**3),
                'disk_usage_percent': (disk_usage.used / disk_usage.total) * 100,
                'disk_read_bytes': disk_io.read_bytes if disk_io else 0,
                'disk_write_bytes': disk_io.write_bytes if disk_io else 0,
                'disk_read_count': disk_io.read_count if disk_io else 0,
                'disk_write_count': disk_io.write_count if disk_io else 0
            }
            
            return metrics
        except Exception as e:
            self.logger.error(f"Error getting disk metrics: {e}")
            return {}
            
    def get_network_metrics(self):
        """Get network metrics"""
        try:
            network_io = psutil.net_io_counters()
            
            metrics = {
                'network_bytes_sent': network_io.bytes_sent,
                'network_bytes_recv': network_io.bytes_recv,
                'network_packets_sent': network_io.packets_sent,
                'network_packets_recv': network_io.packets_recv,
                'network_errin': network_io.errin,
                'network_errout': network_io.errout,
                'network_dropin': network_io.dropin,
                'network_dropout': network_io.dropout
            }
            
            return metrics
        except Exception as e:
            self.logger.error(f"Error getting network metrics: {e}")
            return {}
            
    def get_system_metrics(self):
        """Get system-level metrics"""
        try:
            boot_time = psutil.boot_time()
            uptime_seconds = time.time() - boot_time
            uptime_hours = uptime_seconds / 3600
            
            metrics = {
                'uptime_hours': uptime_hours,
                'boot_time': boot_time,
                'process_count': len(psutil.pids()),
                'load_average': list(psutil.getloadavg()) if hasattr(psutil, 'getloadavg') else None
            }
            
            # Temperature sensors (if available)
            try:
                temps = psutil.sensors_temperatures()
                if temps:
                    temp_data = {}
                    for name, entries in temps.items():
                        for entry in entries:
                            temp_data[f"{name}_{entry.label or 'temp'}"] = entry.current
                    metrics['temperature'] = temp_data
            except (AttributeError, NotImplementedError):
                metrics['temperature'] = {}
                
            return metrics
        except Exception as e:
            self.logger.error(f"Error getting system metrics: {e}")
            return {}
            
    def collect_all_metrics(self):
        """Collect all system metrics"""
        timestamp = datetime.utcnow().isoformat()
        
        all_metrics = {}
        all_metrics.update(self.get_cpu_metrics())
        all_metrics.update(self.get_memory_metrics())
        all_metrics.update(self.get_disk_metrics())
        all_metrics.update(self.get_network_metrics())
        all_metrics.update(self.get_system_metrics())
        
        return timestamp, all_metrics
        
    def format_for_influxdb(self, timestamp, metrics):
        """Format metrics for InfluxDB"""
        point = {
            "measurement": "system_metrics",
            "time": timestamp,
            "fields": {}
        }
        
        # Add all numeric metrics to fields
        for key, value in metrics.items():
            if isinstance(value, (int, float)):
                point["fields"][key] = value
            elif isinstance(value, dict):
                # Handle nested dictionaries (like temperature sensors)
                for sub_key, sub_value in value.items():
                    if isinstance(sub_value, (int, float)):
                        point["fields"][f"{key}_{sub_key}"] = sub_value
                        
        # Add tags
        point["tags"] = {
            "hostname": psutil.os.uname().nodename if hasattr(psutil.os, 'uname') else "unknown",
            "os": psutil.os.name if hasattr(psutil.os, 'name') else "unknown"
        }
        
        return point
        
    def write_to_influxdb(self, point):
        """Write metrics to InfluxDB"""
        try:
            # Convert to InfluxDB v2 format
            bucket = os.getenv('INFLUXDB_DB', 'seaker_metrics')
            
            # Create a point in the new format
            p = Point(point["measurement"]) \
                .tag("hostname", point["tags"]["hostname"]) \
                .tag("os", point["tags"]["os"])
            
            # Add fields
            for field_name, field_value in point["fields"].items():
                if isinstance(field_value, (int, float)):
                    p = p.field(field_name, field_value)
            
            # Set time
            p = p.time(point["time"])
            
            # Write to InfluxDB
            self.write_api.write(bucket=bucket, record=p)
            self.logger.debug("Metrics written to InfluxDB")
        except Exception as e:
            self.logger.error(f"Failed to write to InfluxDB: {e}")
            
    def run(self):
        """Main collection loop"""
        collection_interval = int(os.getenv('COLLECTION_INTERVAL', 30))
        
        self.logger.info(f"Starting metrics collection with {collection_interval}s interval")
        
        while True:
            try:
                timestamp, metrics = self.collect_all_metrics()
                
                if metrics:
                    point = self.format_for_influxdb(timestamp, metrics)
                    self.write_to_influxdb(point)
                    
                    self.logger.info(f"Collected {len(metrics)} metrics at {timestamp}")
                else:
                    self.logger.warning("No metrics collected")
                    
            except Exception as e:
                self.logger.error(f"Error in collection loop: {e}")
                
            time.sleep(collection_interval)

if __name__ == "__main__":
    collector = MetricsCollector()
    collector.run()
