#!/usr/bin/env python3
"""
Configuration Manager for Seaker-Alert-App
Handles loading and managing configuration files
"""

import json
import os
import logging
from typing import Dict, Any

class ConfigManager:
    def __init__(self):
        self.config_dir = '/app/config'
        self.thresholds_file = os.path.join(self.config_dir, 'thresholds.json')
        self.notifications_file = os.path.join(self.config_dir, 'notifications.json')
        self.logger = logging.getLogger(__name__)
        self.ensure_config_files()
        
    def ensure_config_files(self):
        """Ensure configuration files exist with default values"""
        os.makedirs(self.config_dir, exist_ok=True)
        
        # Create default thresholds file
        if not os.path.exists(self.thresholds_file):
            default_thresholds = {
                "cpu_usage": {
                    "warning": 70,
                    "critical": 90
                },
                "memory_usage": {
                    "warning": 80,
                    "critical": 95
                },
                "disk_usage": {
                    "warning": 85,
                    "critical": 95
                },
                "temperature": {
                    "warning": 70,
                    "critical": 85
                },
                "swap_usage": {
                    "warning": 50,
                    "critical": 80
                }
            }
            with open(self.thresholds_file, 'w') as f:
                json.dump(default_thresholds, f, indent=2)
            self.logger.info(f"Created default thresholds file: {self.thresholds_file}")
            
        # Create default notifications file
        if not os.path.exists(self.notifications_file):
            default_notifications = {
                "email": {
                    "enabled": False,
                    "smtp_server": "smtp.gmail.com",
                    "smtp_port": 587,
                    "username": "",
                    "password": "",
                    "recipients": []
                },
                "slack": {
                    "enabled": False,
                    "webhook_url": ""
                },
                "console": {
                    "enabled": True
                }
            }
            with open(self.notifications_file, 'w') as f:
                json.dump(default_notifications, f, indent=2)
            self.logger.info(f"Created default notifications file: {self.notifications_file}")
            
    def load_config(self, config_file: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            self.logger.error(f"Configuration file not found: {config_file}")
            return {}
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in {config_file}: {e}")
            return {}
        except Exception as e:
            self.logger.error(f"Error loading {config_file}: {e}")
            return {}
            
    def save_config(self, config_file: str, config: Dict[str, Any]):
        """Save configuration to JSON file"""
        try:
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
            self.logger.info(f"Configuration saved to {config_file}")
        except Exception as e:
            self.logger.error(f"Error saving configuration to {config_file}: {e}")
            
    def get_thresholds(self) -> Dict[str, Any]:
        """Get alert thresholds"""
        return self.load_config(self.thresholds_file)
        
    def update_thresholds(self, thresholds: Dict[str, Any]):
        """Update alert thresholds"""
        self.save_config(self.thresholds_file, thresholds)
        
    def get_notifications(self) -> Dict[str, Any]:
        """Get notification configuration"""
        return self.load_config(self.notifications_file)
        
    def update_notifications(self, notifications: Dict[str, Any]):
        """Update notification configuration"""
        self.save_config(self.notifications_file, notifications)
