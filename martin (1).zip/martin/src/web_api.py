#!/usr/bin/env python3
"""
Web API for Seaker-Alert-App
Provides REST API for metrics, configuration, and alerts
"""

from flask import Flask, jsonify, request
from influxdb import InfluxDBClient
import os
import logging
from datetime import datetime, timedelta
from config_manager import ConfigManager
from alert_engine import AlertEngine

app = Flask(__name__)

# Global instances
config_manager = ConfigManager()
alert_engine = None

def setup_logging():
    """Setup logging configuration"""
    log_dir = '/app/logs'
    os.makedirs(log_dir, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'{log_dir}/web_api.log'),
            logging.StreamHandler()
        ]
    )

def get_influx_client():
    """Get InfluxDB client"""
    return InfluxDBClient(
        host=os.getenv('INFLUXDB_HOST', 'localhost'),
        port=int(os.getenv('INFLUXDB_PORT', 8086)),
        username=os.getenv('INFLUXDB_USER', 'seaker'),
        password=os.getenv('INFLUXDB_PASSWORD', 'seaker123'),
        database=os.getenv('INFLUXDB_DB', 'seaker_metrics')
    )

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        influx_client = get_influx_client()
        influx_client.query('SHOW DATABASES')
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'services': {
                'influxdb': 'connected',
                'config': 'loaded'
            }
        })
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/metrics', methods=['GET'])
def get_metrics():
    """Get current system metrics"""
    try:
        influx_client = get_influx_client()
        
        # Get latest metrics from last 5 minutes
        time_range = request.args.get('time_range', '5m')
        
        query = f'''
        SELECT mean(*) 
        FROM "system_metrics" 
        WHERE time > now() - {time_range} 
        GROUP BY time(1m) fill(null)
        '''
        
        result = influx_client.query(query)
        
        if result:
            points = list(result.get_points())
            if points:
                # Get the most recent data point
                latest_point = points[-1]
                return jsonify({
                    'timestamp': latest_point.get('time'),
                    'metrics': {k: v for k, v in latest_point.items() if k not in ['time']}
                })
        
        return jsonify({'error': 'No metrics found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/metrics/history', methods=['GET'])
def get_metrics_history():
    """Get historical metrics data"""
    try:
        influx_client = get_influx_client()
        
        # Get query parameters
        metric = request.args.get('metric', 'cpu_usage_percent')
        time_range = request.args.get('time_range', '1h')
        interval = request.args.get('interval', '5m')
        
        query = f'''
        SELECT mean("{metric}") 
        FROM "system_metrics" 
        WHERE time > now() - {time_range} 
        GROUP BY time({interval}) fill(null)
        '''
        
        result = influx_client.query(query)
        
        if result:
            points = list(result.get_points())
            return jsonify({
                'metric': metric,
                'time_range': time_range,
                'interval': interval,
                'data': points
            })
        
        return jsonify({'error': 'No data found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/thresholds', methods=['GET'])
def get_thresholds():
    """Get alert thresholds"""
    try:
        thresholds = config_manager.get_thresholds()
        return jsonify(thresholds)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/thresholds', methods=['POST'])
def update_thresholds():
    """Update alert thresholds"""
    try:
        new_thresholds = request.json
        config_manager.update_thresholds(new_thresholds)
        return jsonify({
            'status': 'success',
            'message': 'Thresholds updated successfully',
            'thresholds': new_thresholds
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/notifications', methods=['GET'])
def get_notifications():
    """Get notification configuration"""
    try:
        notifications = config_manager.get_notifications()
        return jsonify(notifications)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/notifications', methods=['POST'])
def update_notifications():
    """Update notification configuration"""
    try:
        new_notifications = request.json
        config_manager.update_notifications(new_notifications)
        return jsonify({
            'status': 'success',
            'message': 'Notification configuration updated successfully',
            'notifications': new_notifications
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/alerts', methods=['GET'])
def get_alerts():
    """Get current alert status"""
    try:
        global alert_engine
        if alert_engine is None:
            alert_engine = AlertEngine()
            
        status = alert_engine.get_system_status()
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/alerts/test', methods=['POST'])
def test_alert():
    """Send a test alert"""
    try:
        from notification_service import NotificationService
        
        notification_service = NotificationService()
        
        # Get test parameters
        title = request.json.get('title', 'Test Alert')
        message = request.json.get('message', 'This is a test alert from Seaker-Alert-App')
        level = request.json.get('level', 'warning')
        
        notification_service.send_alert(title, message, level)
        
        return jsonify({
            'status': 'success',
            'message': 'Test alert sent successfully'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/csv', methods=['GET'])
def export_csv():
    """Export metrics data as CSV"""
    try:
        import pandas as pd
        from io import StringIO
        
        influx_client = get_influx_client()
        
        # Get query parameters
        time_range = request.args.get('time_range', '24h')
        
        query = f'''
        SELECT * 
        FROM "system_metrics" 
        WHERE time > now() - {time_range}
        '''
        
        result = influx_client.query(query)
        
        if result:
            points = list(result.get_points())
            if points:
                df = pd.DataFrame(points)
                
                # Convert to CSV
                output = StringIO()
                df.to_csv(output, index=False)
                csv_data = output.getvalue()
                
                return csv_data, 200, {
                    'Content-Type': 'text/csv',
                    'Content-Disposition': f'attachment; filename=metrics_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
                }
        
        return jsonify({'error': 'No data found'}), 404
        
    except ImportError:
        return jsonify({'error': 'pandas not installed for CSV export'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/json', methods=['GET'])
def export_json():
    """Export metrics data as JSON"""
    try:
        influx_client = get_influx_client()
        
        # Get query parameters
        time_range = request.args.get('time_range', '24h')
        
        query = f'''
        SELECT * 
        FROM "system_metrics" 
        WHERE time > now() - {time_range}
        '''
        
        result = influx_client.query(query)
        
        if result:
            points = list(result.get_points())
            return jsonify({
                'export_time': datetime.now().isoformat(),
                'time_range': time_range,
                'data': points
            })
        
        return jsonify({'error': 'No data found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    setup_logging()
    app.run(host='0.0.0.0', port=5000, debug=False)
