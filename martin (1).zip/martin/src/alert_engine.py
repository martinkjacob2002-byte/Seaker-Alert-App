#!/usr/bin/env python3
"""
Alert Engine for Seaker-Alert-App
Monitors metrics and triggers alerts based on thresholds
"""

import time
import logging
import os
from datetime import datetime, timedelta
from influxdb import InfluxDBClient
from config_manager import ConfigManager
from notification_service import NotificationService

class AlertEngine:
    def __init__(self):
        self.config = ConfigManager()
        self.notification_service = NotificationService()
        self.influx_client = None
        self.alert_history = {}
        self.setup_logging()
        self.setup_influxdb()
        
    def setup_logging(self):
        """Setup logging configuration"""
        log_dir = '/app/logs'
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(f'{log_dir}/alert_engine.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def setup_influxdb(self):
        """Setup InfluxDB connection"""
        try:
            self.influx_client = InfluxDBClient(
                host=os.getenv('INFLUXDB_HOST', 'localhost'),
                port=int(os.getenv('INFLUXDB_PORT', 8086)),
                username=os.getenv('INFLUXDB_USER', 'seaker'),
                password=os.getenv('INFLUXDB_PASSWORD', 'seaker123'),
                database=os.getenv('INFLUXDB_DB', 'seaker_metrics')
            )
            self.logger.info("Connected to InfluxDB successfully")
        except Exception as e:
            self.logger.error(f"Failed to connect to InfluxDB: {e}")
            raise
            
    def get_latest_metric(self, metric_name, time_range='5m'):
        """Get the latest value for a specific metric"""
        try:
            query = f'SELECT mean("{metric_name}") FROM "system_metrics" WHERE time > now() - {time_range} GROUP BY time(1m) fill(null)'
            result = self.influx_client.query(query)
            
            if result:
                points = list(result.get_points())
                if points:
                    # Get the most recent non-null value
                    for point in reversed(points):
                        if point.get('mean') is not None:
                            return point['mean']
                            
            return None
        except Exception as e:
            self.logger.error(f"Error querying metric {metric_name}: {e}")
            return None
            
    def check_threshold(self, metric_name, value, thresholds):
        """Check if a metric value exceeds thresholds"""
        if value is None:
            return None
            
        warning_threshold = thresholds.get('warning')
        critical_threshold = thresholds.get('critical')
        
        if critical_threshold and value >= critical_threshold:
            return 'critical'
        elif warning_threshold and value >= warning_threshold:
            return 'warning'
            
        return None
        
    def get_alert_key(self, metric_name, level):
        """Generate a unique key for an alert"""
        return f"{metric_name}_{level}"
        
    def should_send_alert(self, alert_key, cooldown_minutes=15):
        """Check if alert should be sent based on cooldown period"""
        if alert_key not in self.alert_history:
            return True
            
        last_sent = self.alert_history[alert_key]
        cooldown_time = timedelta(minutes=cooldown_minutes)
        
        return datetime.now() - last_sent > cooldown_time
        
    def update_alert_history(self, alert_key):
        """Update the alert history with current timestamp"""
        self.alert_history[alert_key] = datetime.now()
        
    def format_alert_message(self, metric_name, value, level, thresholds):
        """Format alert message"""
        level_emoji = "WARNING" if level == 'warning' else "CRITICAL"
        
        message = f"""
{level_emoji} ALERT: {metric_name.replace('_', ' ').title()}

Current Value: {value:.2f}
Threshold: {thresholds[level]}%
Level: {level.upper()}

Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Please check the system immediately.
        """.strip()
        
        return message
        
    def check_all_metrics(self):
        """Check all configured metrics against thresholds"""
        thresholds = self.config.get_thresholds()
        alerts_triggered = []
        
        # Define metric mappings
        metric_mappings = {
            'cpu_usage': 'cpu_usage_percent',
            'memory_usage': 'memory_usage_percent', 
            'disk_usage': 'disk_usage_percent',
            'swap_usage': 'swap_usage_percent',
            'temperature': 'temperature_cpu_thermal'  # Common sensor name
        }
        
        for threshold_key, metric_name in metric_mappings.items():
            if threshold_key in thresholds:
                # Get latest metric value
                value = self.get_latest_metric(metric_name)
                
                if value is not None:
                    # Check against thresholds
                    level = self.check_threshold(threshold_key, value, thresholds[threshold_key])
                    
                    if level:
                        alert_key = self.get_alert_key(threshold_key, level)
                        
                        if self.should_send_alert(alert_key):
                            # Format and send alert
                            message = self.format_alert_message(
                                threshold_key, value, level, thresholds[threshold_key]
                            )
                            
                            # Send notification
                            self.notification_service.send_alert(
                                f"{threshold_key} {level.upper()}",
                                message,
                                level
                            )
                            
                            # Update alert history
                            self.update_alert_history(alert_key)
                            
                            alerts_triggered.append({
                                'metric': threshold_key,
                                'value': value,
                                'level': level,
                                'time': datetime.now()
                            })
                            
                            self.logger.warning(f"Alert triggered: {threshold_key} = {value:.2f} ({level.upper()})")
                        else:
                            self.logger.debug(f"Alert {alert_key} in cooldown period")
                            
        return alerts_triggered
        
    def get_system_status(self):
        """Get current system status summary"""
        status = {
            'timestamp': datetime.now().isoformat(),
            'metrics': {},
            'alerts': []
        }
        
        # Get current values for key metrics
        metrics_to_check = ['cpu_usage_percent', 'memory_usage_percent', 'disk_usage_percent']
        
        for metric in metrics_to_check:
            value = self.get_latest_metric(metric)
            if value is not None:
                status['metrics'][metric] = value
                
        # Get recent alerts
        thresholds = self.config.get_thresholds()
        metric_mappings = {
            'cpu_usage': 'cpu_usage_percent',
            'memory_usage': 'memory_usage_percent', 
            'disk_usage': 'disk_usage_percent'
        }
        
        for threshold_key, metric_name in metric_mappings.items():
            if threshold_key in thresholds:
                value = self.get_latest_metric(metric_name)
                if value is not None:
                    level = self.check_threshold(threshold_key, value, thresholds[threshold_key])
                    if level:
                        status['alerts'].append({
                            'metric': threshold_key,
                            'value': value,
                            'level': level
                        })
                        
        return status
        
    def run(self):
        """Main alert monitoring loop"""
        check_interval = int(os.getenv('ALERT_CHECK_INTERVAL', 60))
        
        self.logger.info(f"Starting alert engine with {check_interval}s check interval")
        
        while True:
            try:
                alerts = self.check_all_metrics()
                
                if alerts:
                    self.logger.info(f"Processed {len(alerts)} alerts")
                else:
                    self.logger.debug("No alerts triggered")
                    
            except Exception as e:
                self.logger.error(f"Error in alert monitoring loop: {e}")
                
            time.sleep(check_interval)

if __name__ == "__main__":
    alert_engine = AlertEngine()
    alert_engine.run()
