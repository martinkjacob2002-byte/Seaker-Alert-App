// Dashboard JavaScript for Seaker Alert App
// This handles all the frontend stuff

// Global vars - yeah I know, globals aren't ideal but it's a small project
let refreshInterval;
let metricsChart;
let chartData = {
    labels: [],
    cpu: [],
    memory: [],
    disk: []
};
let autoRefreshEnabled = true;
let countdownInterval;
let secondsUntilRefresh = 3;

// Config stuff
const CONFIG = {
    REFRESH_INTERVAL: 3000, // 3 seconds - pretty fast for real-time
    MAX_CHART_POINTS: 20,
    CHART_HEIGHT: 120
};

// Initialize everything when page loads
document.addEventListener('DOMContentLoaded', function() {
    try {
        initChart();
        updateMetrics();
        startAutoRefresh();
        console.log('Dashboard initialized successfully');
    } catch (error) {
        console.error('Error initializing dashboard:', error);
        showError('Failed to initialize dashboard');
    }
});

// Initialize main chart
function initChart() {
    const ctx = document.getElementById('metricsChart');
    if (!ctx) {
        throw new Error('Chart canvas element not found');
    }

    metricsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [
                {
                    label: 'CPU',
                    data: chartData.cpu,
                    borderColor: '#F44336',
                    backgroundColor: 'rgba(244, 67, 54, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Memory',
                    data: chartData.memory,
                    borderColor: '#2196F3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Disk',
                    data: chartData.disk,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

// Update metrics from API
function updateMetrics() {
    console.log('Updating metrics...');
    document.getElementById('refreshStatus').textContent = 'Updating...';
    
    fetch('/metrics')
        .then(response => {
            console.log('Response status:', response.status);
            if (!response.ok) {
                throw new Error('HTTP error! status: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Received data:', data);
            updateUI(data);
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('refreshStatus').textContent = 'Error: ' + error.message;
        });
}

// Update UI with new data
function updateUI(data) {
    // Update metric boxes
    const metrics = {
        cpuCores: data.cpu_count || '--',
        cpuUsage: (data.cpu_usage_percent || 0).toFixed(1),
        memoryValue: `${(data.memory_used_gb || 0).toFixed(1)} / ${(data.memory_total_gb || 0).toFixed(1)}`,
        memoryUsage: (data.memory_usage_percent || 0).toFixed(1),
        diskValue: `${(data.disk_used_gb || 0).toFixed(1)} / ${(data.disk_total_gb || 0).toFixed(1)}`,
        diskUsage: (data.disk_usage_percent || 0).toFixed(1),
        uptime: (data.uptime_hours || 0).toFixed(1),
        processes: data.process_count || '--'
    };

    Object.keys(metrics).forEach(key => {
        const element = document.getElementById(key);
        if (element) {
            element.textContent = metrics[key];
        }
    });

    // Update progress bars
    updateProgressBar('cpuBar', data.cpu_usage_percent || 0);
    updateProgressBar('memoryBar', data.memory_usage_percent || 0);
    updateProgressBar('diskBar', data.disk_usage_percent || 0);
    
    document.getElementById('cpuPercent').textContent = (data.cpu_usage_percent || 0).toFixed(1) + '%';
    document.getElementById('memoryPercent').textContent = (data.memory_usage_percent || 0).toFixed(1) + '%';
    document.getElementById('diskPercent').textContent = (data.disk_usage_percent || 0).toFixed(1) + '%';
    
    // Update chart
    const now = new Date();
    const timeLabel = now.toLocaleTimeString();
    
    // Keep only last MAX_CHART_POINTS
    if (chartData.labels.length > CONFIG.MAX_CHART_POINTS) {
        chartData.labels.shift();
        chartData.cpu.shift();
        chartData.memory.shift();
        chartData.disk.shift();
    }
    
    chartData.labels.push(timeLabel);
    chartData.cpu.push(data.cpu_usage_percent || 0);
    chartData.memory.push(data.memory_usage_percent || 0);
    chartData.disk.push(data.disk_usage_percent || 0);
    
    if (metricsChart) {
        metricsChart.update();
    }
    
    // Update status
    document.getElementById('status').className = 'status status-online';
    document.getElementById('statusText').textContent = 'System Online';
    
    // Update timestamp
    document.getElementById('timestamp').textContent = 'Last updated: ' + now.toLocaleString();
    
    // Hide loading and show dashboard
    document.getElementById('loading').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
    
    document.getElementById('refreshStatus').textContent = 'Updated successfully';
}

// Update progress bar with color coding
function updateProgressBar(barId, value) {
    const bar = document.getElementById(barId);
    if (bar) {
        bar.style.width = value + '%';
        bar.className = 'progress-fill';
        if (value >= 90) {
            bar.classList.add('progress-red');
        } else if (value >= 70) {
            bar.classList.add('progress-yellow');
        } else {
            bar.classList.add('progress-green');
        }
    }
}

// Test alert function
function testAlert() {
    alert('Test alert functionality');
}

// Export functions
function exportJSON() {
    fetch('/metrics')
        .then(response => response.json())
        .then(data => {
            const jsonStr = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'system_metrics_' + new Date().toISOString().slice(0, 10) + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        })
        .catch(error => {
            console.error('Error exporting JSON:', error);
            alert('Error exporting data');
        });
}

function exportCSV() {
    fetch('/metrics')
        .then(response => response.json())
        .then(data => {
            let csv = 'Metric,Value,Unit\n';
            csv += `CPU Usage,${(data.cpu_usage_percent || 0).toFixed(1)},%\n`;
            csv += `Memory Used,${(data.memory_used_gb || 0).toFixed(2)},GB\n`;
            csv += `Memory Total,${(data.memory_total_gb || 0).toFixed(2)},GB\n`;
            csv += `Memory Usage,${(data.memory_usage_percent || 0).toFixed(1)},%\n`;
            csv += `Disk Used,${(data.disk_used_gb || 0).toFixed(2)},GB\n`;
            csv += `Disk Total,${(data.disk_total_gb || 0).toFixed(2)},GB\n`;
            csv += `Disk Usage,${(data.disk_usage_percent || 0).toFixed(1)},%\n`;
            csv += `Uptime,${(data.uptime_hours || 0).toFixed(1)},hours\n`;
            csv += `Process Count,${data.process_count || 0},count\n`;
            
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'system_metrics_' + new Date().toISOString().slice(0, 10) + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        })
        .catch(error => {
            console.error('Error exporting CSV:', error);
            alert('Error exporting data');
        });
}

// Auto-refresh functionality
function startAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
    
    refreshInterval = setInterval(updateMetrics, CONFIG.REFRESH_INTERVAL);
    startCountdown();
}

function startCountdown() {
    secondsUntilRefresh = 3;
    countdownInterval = setInterval(() => {
        secondsUntilRefresh--;
        updateRefreshStatus();
        if (secondsUntilRefresh <= 0) {
            secondsUntilRefresh = 3;
        }
    }, 1000);
}

function updateRefreshStatus() {
    document.getElementById('refreshStatus').textContent = 'Next refresh in ' + secondsUntilRefresh + 's';
}

// Error handling
function showError(message) {
    console.error(message);
    const errorElement = document.getElementById('error');
    if (errorElement) {
        errorElement.style.display = 'block';
        errorElement.querySelector('div').textContent = message;
    }
}

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
});
