// Seaker-Alert-App Dashboard JavaScript

// Global variables
let refreshInterval;
let metricsChart;
let chartData = {
    labels: [],
    cpu: [],
    memory: [],
    disk: []
};
let autoRefreshEnabled = true;
let countdownInterval;
let secondsUntilRefresh = 30;

// Configuration
const CONFIG = {
    REFRESH_INTERVAL: 30000, // 30 seconds
    MAX_CHART_POINTS: 20,
    CHART_HEIGHT: 120
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    try {
        initChart();
        updateMetrics();
        startAutoRefresh();
        console.log('Dashboard initialized successfully');
    } catch (error) {
        console.error('Error initializing dashboard:', error);
        showError('Failed to initialize dashboard');
    }
});

// Initialize main chart
function initChart() {
    const ctx = document.getElementById('metricsChart');
    if (!ctx) {
        throw new Error('Chart canvas element not found');
    }

    metricsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [
                {
                    label: 'CPU',
                    data: chartData.cpu,
                    borderColor: '#F44336',
                    backgroundColor: 'rgba(244, 67, 54, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Memory',
                    data: chartData.memory,
                    borderColor: '#2196F3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Disk',
                    data: chartData.disk,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 12,
                        padding: 10,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: {
                        size: 12
                    },
                    bodyFont: {
                        size: 11
                    }
                }
            },
            scales: {
                x: {
                    display: true,
                    grid: {
                        display: false
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45,
                        font: {
                            size: 10
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    ticks: {
                        font: {
                            size: 10
                        },
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        }
    });
}

// Update all metrics
function updateMetrics() {
    fetch('/metrics')
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP error! status: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            updateMetricBoxes(data);
            updateProgressBars(data);
            updateChart(data);
            updateStatus(true);
            updateAlerts();
            updateTimestamp();
        })
        .catch(error => {
            console.error('Error fetching metrics:', error);
            updateStatus(false);
            showError('Failed to load metrics. Please try again.');
        });
}

// Update metric boxes
function updateMetricBoxes(data) {
    const metrics = {
        cpuCores: data.cpu_count || '--',
        cpuUsage: (data.cpu_usage_percent || 0).toFixed(1),
        memoryValue: `${(data.memory_used_gb || 0).toFixed(1)} / ${(data.memory_total_gb || 0).toFixed(1)}`,
        memoryUsage: (data.memory_usage_percent || 0).toFixed(1),
        diskValue: `${(data.disk_used_gb || 0).toFixed(1)} / ${(data.disk_total_gb || 0).toFixed(1)}`,
        diskUsage: (data.disk_usage_percent || 0).toFixed(1),
        uptime: (data.uptime_hours || 0).toFixed(1),
        processes: data.process_count || '--'
    };

    Object.keys(metrics).forEach(key => {
        const element = document.getElementById(key);
        if (element) {
            element.textContent = metrics[key];
        }
    });
}

// Update progress bars
function updateProgressBars(data) {
    const metrics = {
        cpu: data.cpu_usage_percent || 0,
        memory: data.memory_usage_percent || 0,
        disk: data.disk_usage_percent || 0
    };

    Object.keys(metrics).forEach(key => {
        const value = metrics[key];
        const bar = document.getElementById(key + 'Bar');
        const percent = document.getElementById(key + 'Percent');

        if (bar) {
            updateProgressBar(bar, value);
        }
        if (percent) {
            percent.textContent = value.toFixed(1) + '%';
        }
    });
}

// Update progress bar with color
function updateProgressBar(bar, value) {
    bar.style.width = value + '%';
    
    // Remove existing color classes
    bar.className = 'progress-fill';
    
    // Add appropriate color class
    if (value >= 90) {
        bar.classList.add('progress-red');
    } else if (value >= 70) {
        bar.classList.add('progress-yellow');
    } else {
        bar.classList.add('progress-green');
    }
}

// Update main chart
function updateChart(data) {
    const now = new Date();
    const timeLabel = now.toLocaleTimeString();

    // Limit data points
    if (chartData.labels.length >= CONFIG.MAX_CHART_POINTS) {
        chartData.labels.shift();
        chartData.cpu.shift();
        chartData.memory.shift();
        chartData.disk.shift();
    }

    // Add new data
    chartData.labels.push(timeLabel);
    chartData.cpu.push(data.cpu_usage_percent || 0);
    chartData.memory.push(data.memory_usage_percent || 0);
    chartData.disk.push(data.disk_usage_percent || 0);

    // Update chart
    if (metricsChart) {
        metricsChart.update('none');
    }
}

// Update status indicator
function updateStatus(isOnline) {
    const statusElement = document.getElementById('status');
    const statusText = document.getElementById('statusText');

    if (statusElement && statusText) {
        if (isOnline) {
            statusElement.className = 'status status-online';
            statusText.textContent = 'System Online';
        } else {
            statusElement.className = 'status status-offline';
            statusText.textContent = 'Connection Error';
        }
    }
}

// Update alerts
function updateAlerts() {
    fetch('/alerts')
        .then(response => response.json())
        .then(data => {
            const alertsList = document.getElementById('alertsList');
            if (!alertsList) return;

            if (data.alerts && data.alerts.length > 0) {
                alertsList.innerHTML = data.alerts.map(alert => {
                    const levelClass = alert.level || 'warning';
                    return '<div class="alert-item ' + levelClass + '">' +
                        '<strong>' + alert.level.toUpperCase() + '</strong>: ' +
                        alert.metric + ' = ' + alert.value.toFixed(1) + '% (threshold: ' + alert.threshold + '%)' +
                        '</div>';
                }).join('');
            } else {
                alertsList.innerHTML = '<div class="no-alerts">No active alerts</div>';
            }
        })
        .catch(error => console.error('Error fetching alerts:', error));
}

// Update timestamp
function updateTimestamp() {
    const timestampElement = document.getElementById('timestamp');
    if (timestampElement) {
        timestampElement.textContent = 'Last updated: ' + new Date().toLocaleString();
    }
}

// Show loading state
function showLoading() {
    const loadingElement = document.getElementById('loading');
    const dashboardElement = document.getElementById('dashboard');
    
    if (loadingElement) loadingElement.style.display = 'block';
    if (dashboardElement) dashboardElement.style.display = 'none';
}

// Hide loading state
function hideLoading() {
    const loadingElement = document.getElementById('loading');
    const dashboardElement = document.getElementById('dashboard');
    
    if (loadingElement) loadingElement.style.display = 'none';
    if (dashboardElement) dashboardElement.style.display = 'block';
}

// Show error message
function showError(message) {
    const errorElement = document.getElementById('error');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
    
    setTimeout(() => {
        if (errorElement) {
            errorElement.style.display = 'none';
        }
    }, 5000);
}

// Start auto-refresh
function startAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    
    if (autoRefreshEnabled) {
        refreshInterval = setInterval(updateMetrics, CONFIG.REFRESH_INTERVAL);
        startCountdown();
    }
}

// Start countdown timer
function startCountdown() {
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
    
    secondsUntilRefresh = CONFIG.REFRESH_INTERVAL / 1000;
    
    countdownInterval = setInterval(() => {
        secondsUntilRefresh--;
        updateRefreshStatus();
        
        if (secondsUntilRefresh <= 0) {
            secondsUntilRefresh = CONFIG.REFRESH_INTERVAL / 1000;
        }
    }, 1000);
}

// Update refresh status display
function updateRefreshStatus() {
    const statusElement = document.getElementById('refreshStatus');
    if (statusElement) {
        if (autoRefreshEnabled) {
            statusElement.textContent = 'Next refresh in ' + secondsUntilRefresh + 's';
        } else {
            statusElement.textContent = 'Auto-refresh disabled';
        }
    }
}

// Toggle auto-refresh
function toggleAutoRefresh() {
    autoRefreshEnabled = !autoRefreshEnabled;
    const btn = document.getElementById('autoRefreshBtn');
    
    if (autoRefreshEnabled) {
        btn.textContent = 'Auto-Refresh: ON';
        btn.className = 'btn auto-refresh-on';
        startAutoRefresh();
    } else {
        btn.textContent = 'Auto-Refresh: OFF';
        btn.className = 'btn auto-refresh-off';
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
        if (countdownInterval) {
            clearInterval(countdownInterval);
        }
        updateRefreshStatus();
    }
}

// Public functions
function refreshData() {
    updateMetrics();
}

function testAlert() {
    fetch('/alerts/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            title: 'Test Alert',
            message: 'This is a test alert from dashboard!',
            level: 'warning'
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Test alert sent:', data);
        alert('Test alert sent successfully!');
    })
    .catch(error => {
        console.error('Error sending test alert:', error);
        alert('Error sending test alert.');
    });
}

function exportData() {
    window.open('/export/json', '_blank');
}

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
});

// Handle visibility change (pause refresh when tab is not visible)
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
    } else {
        startAutoRefresh();
        updateMetrics();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(event) {
    if (event.key === 'r' && event.ctrlKey) {
        event.preventDefault();
        refreshData();
    } else if (event.key === 't' && event.ctrlKey) {
        event.preventDefault();
        testAlert();
    } else if (event.key === 'e' && event.ctrlKey) {
        event.preventDefault();
        exportData();
    }
});
